<?php

// +---------------------------------------------------------------------------+
// | Open Graph Protocol Plugin for Geeklog - The Ultimate Weblog              |
// +---------------------------------------------------------------------------+
// | geeklog/plugins/ogp/autoinstall.php                                       |
// +---------------------------------------------------------------------------+
// | Copyright (C) 2011-2020 mystral-kk - mystralkk AT gmail DOT com           |
// |                                                                           |
// | Constructed with the Universal Plugin                                     |
// +---------------------------------------------------------------------------+
// |                                                                           |
// | This program is free software; you can redistribute it and/or             |
// | modify it under the terms of the GNU General Public License               |
// | as published by the Free Software Foundation; either version 2            |
// | of the License, or (at your option) any later version.                    |
// |                                                                           |
// | This program is distributed in the hope that it will be useful,           |
// | but WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
// | GNU General Public License for more details.                              |
// |                                                                           |
// | You should have received a copy of the GNU General Public License         |
// | along with this program; if not, write to the Free Software Foundation,   |
// | Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.           |
// |                                                                           |
// +---------------------------------------------------------------------------+

if (stripos($_SERVER['PHP_SELF'], basename(__FILE__)) !== false) {
    die('This file can not be used on its own!');
}

require_once dirname(__FILE__) . '/install_defaults.php';

// Open Graph Protocol Plugin Main Settings
$_CONF_VALIDATE['ogp']['fb_user_ids']        = array('rule' => 'stringOrEmpty');
$_CONF_VALIDATE['ogp']['fb_app_id']          = array('rule' => 'stringOrEmpty');
$_CONF_VALIDATE['ogp']['fb_default_img_url'] = array('rule' => 'stringOrEmpty');
$_CONF_VALIDATE['ogp']['like_width']         = array('rule' => 'numeric');
$_CONF_VALIDATE['ogp']['comments_num_posts'] = array('rule' => 'numeric');
$_CONF_VALIDATE['ogp']['comments_width']     = array('rule' => 'numeric');
$_CONF_VALIDATE['ogp']['types']              = array(
    'rule' => array('inList', $_OGP_DEFAULT['types'])
);
